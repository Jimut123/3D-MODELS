
==============================================
                    Auteur / Author : Patrice MONIEZ
                         E-mail: pmoniez@tiscali.fr

                           software: Lightwave 3D

                Tous droits r�serv�s.  All rights reserved.

==============================================
Downloaded from DMI at http://dmi.chez.tiscali.fr/models1.html